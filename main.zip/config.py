DB_NAME = 'c77628_akbarjon_forum_na4u_ru'
DB_USER = 'c77628_akbarjon_forum_na4u_ru'
DB_PASSWORD = 'FiBvaNidzozam70'
DB_HOST = 'postgres.c77628.h2'